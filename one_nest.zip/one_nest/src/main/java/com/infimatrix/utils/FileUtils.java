package com.infimatrix.utils;

import java.io.File;

public class FileUtils {

    public static void copyFile(File screenshotFile, File file) {
    }

}
